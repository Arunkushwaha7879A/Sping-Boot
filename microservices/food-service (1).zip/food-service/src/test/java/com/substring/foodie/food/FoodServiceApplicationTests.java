package com.substring.foodie.food;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
